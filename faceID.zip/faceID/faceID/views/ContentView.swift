//
//  ContentView.swift
//  faceID
//
//  Created by Varsha Sureshbabu on 21/11/21.
//

import SwiftUI

struct ContentView: View {
    @StateObject var authmanager = AuthenticationManager()
    var body: some View {
        VStack{
            loginview().environmentObject(authmanager)
        }
        .frame(maxWidth:.infinity,maxHeight:.infinity)
        .edgesIgnoringSafeArea(.all)
        .alert(isPresented: $authmanager.showAlert){
            Alert(title: Text("Error"), message: Text(authmanager.errorDescription ?? "Error trying to login with credentials, please try again."), dismissButton: .default(Text("Ok")))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
