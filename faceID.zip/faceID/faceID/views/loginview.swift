//
//  loginview.swift
//  faceID
//
//  Created by Varsha Sureshbabu on 21/11/21.
//

import SwiftUI

struct loginview: View {
    @EnvironmentObject var authManager: AuthenticationManager
    
    
    var body: some View {
        VStack(spacing:40){
            tite()
            
            switch authManager.biometrictype{
            case.faceID: primarybutton(image: "faceid",text: "Login with FaceID").onTapGesture {
                Task.init{
                    await authManager.authenticateWithBiometrics()
                }
            }
                  
            case.touchID: primarybutton(image:"touchid",text:"Login with TouchID").onTapGesture {
                Task.init{
                    await authManager.authenticateWithBiometrics()
                }
            }
                
            default:
                primarybutton(image:"person.fill",text:"Login with credentials  ")
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(LinearGradient(colors: [.blue,.purple], startPoint: .topLeading, endPoint: .bottomTrailing))
    }
}

struct loginview_Previews: PreviewProvider {
    static var previews: some View {
        loginview()
            .environmentObject(AuthenticationManager())
    }
}
