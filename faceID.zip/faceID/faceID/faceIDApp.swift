//
//  faceIDApp.swift
//  faceID
//
//  Created by Varsha Sureshbabu on 21/11/21.
//

import SwiftUI

@main
struct faceIDApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
