//
//  tite.swift
//  faceID
//
//  Created by Varsha Sureshbabu on 21/11/21.
//

import SwiftUI

struct tite: View {
    var body: some View {
        Text("Authenticator").bold().font(.title).foregroundColor(.white)
    }
}

struct tite_Previews: PreviewProvider {
    static var previews: some View {
        tite().background(LinearGradient(colors: [.blue,.purple], startPoint: .topLeading, endPoint: .bottomLeading))
    }
}
