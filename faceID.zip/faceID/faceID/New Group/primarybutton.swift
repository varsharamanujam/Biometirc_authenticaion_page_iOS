//
//  primarybutton.swift
//  faceID
//
//  Created by Varsha Sureshbabu on 21/11/21.
//

import SwiftUI

struct primarybutton: View {
    var image: String?
    var showimage = true
    var text: String
    
    var body: some View {
        HStack{
            if showimage{
                Image(systemName: image ?? "person.fill")
            }
            Text(text)
        }
        .padding()
        .padding(.horizontal)
        .background(.white)
        .cornerRadius(30)
        .shadow (radius: 10)
    }
}

struct primarybutton_Previews: PreviewProvider {
    static var previews: some View {
        primarybutton(image: "faceid", text:"Login with face id")
    }
}
