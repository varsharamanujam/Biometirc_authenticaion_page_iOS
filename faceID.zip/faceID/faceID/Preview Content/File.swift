//
//  File.swift
//  faceID
//
//  Created by Varsha Sureshbabu on 21/11/21.
//

import Foundation
import LocalAuthentication

class AuthenticationManager: ObservableObject{
    private(set) var context = LAContext()
    
    @Published private(set)var biometrictype: LABiometryType = .none
    private (set) var caneval=false
    
    @Published private(set) var isAuthenticated = false
    @Published private(set) var errorDescription: String?
    @Published var showAlert = false
    
    init(){
        getBiometricType()
    }
    
    func getBiometricType(){
        caneval = context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil)
        biometrictype = context.biometryType
        
    }
    func authenticateWithBiometrics() async{
        context = LAContext()
        
        if caneval {
            let reason = "Log into account"
            do{
            let success = try await context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason)
                
                if success {
                    DispatchQueue.main.async{
                        self.isAuthenticated = true
                        print("is Authenticated",self.isAuthenticated)
                    }
                }
            
        }
            catch{
                print(error.localizedDescription)
                DispatchQueue.main.async{
                    self.errorDescription = error.localizedDescription
                    self.showAlert = true
                    self.biometrictype = .none 
                }
            }
    }
    }
    
}
